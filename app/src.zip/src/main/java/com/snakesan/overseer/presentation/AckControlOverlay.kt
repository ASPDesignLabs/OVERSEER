package com.snakesan.overseer.presentation

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.rotary.onRotaryScrollEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Text
import kotlin.math.abs
import kotlin.math.sin

// --- MINI SYNTH ENGINE ---
object MiniSynth {
    private const val SAMPLE_RATE = 44100

    fun playTone(frequency: Float, durationMs: Int) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * durationMs) / 1000
                val buffer = FloatArray(numSamples)

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val signal = sin(2.0 * Math.PI * frequency * t)
                    val progress = i.toFloat() / numSamples
                    val envelope = if (progress < 0.2f) progress / 0.2f else 1.0f - ((progress - 0.2f) / 0.8f)
                    buffer[i] = (signal * envelope).toFloat()
                }
                playSound(buffer)
            } catch (e: Exception) { e.printStackTrace() }
        }.start()
    }

    private fun playSound(floatBuffer: FloatArray) {
        val pcmBuffer = ShortArray(floatBuffer.size)
        for (i in floatBuffer.indices) {
            val sample = (floatBuffer[i].coerceIn(-1.0f, 1.0f) * 0.5f * Short.MAX_VALUE).toInt()
            pcmBuffer[i] = sample.toShort()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcmBuffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcmBuffer, 0, pcmBuffer.size)
            track.play()
        }
    }
}

@Composable
fun AckControlOverlay(
    currentDeck: String,
    currentTarget: String,
    targetLabels: Map<Int, String>,
    currentColor: Int,
    isCryo: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    val focusRequester = remember { FocusRequester() }

    var controlMode by remember { mutableStateOf("DECK") }
    var localTargetIndex by remember { mutableIntStateOf(0) }
    val primaryColor = if(controlMode == "DECK") Color(currentColor) else NeonGreenVal
    var scrollAccumulator by remember { mutableFloatStateOf(0f) }
    val crownThreshold = 50f

    val infiniteTransition = rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse)
    )

    fun playFeedback(mode: String, index: Int) {
        if (mode == "DECK") MiniSynth.playTone(2000f, 30)
        else {
            val freq = if (index >= 8) 1500f else 400f + (index * 100f)
            MiniSynth.playTone(freq, 40)
        }
    }

    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.95f))
            .onRotaryScrollEvent {
                scrollAccumulator += it.verticalScrollPixels
                if (abs(scrollAccumulator) > crownThreshold) {
                    val direction = if (scrollAccumulator > 0) 1 else -1
                    scrollAccumulator = 0f

                    if (controlMode == "DECK") {
                        val cmd = if(direction > 0) "NEXT_DECK" else "PREV_DECK"
                        sendBroadcastCommand(context, cmd)
                        playFeedback("DECK", 0)
                    } else {
                        val next = localTargetIndex + direction
                        localTargetIndex = if(next > 8) 0 else if(next < 0) 8 else next
                        
                        val payload = if(localTargetIndex == 8) -1 else localTargetIndex
                        sendBroadcastCommand(context, "SET_TARGET:$payload")
                        playFeedback("TARGET", localTargetIndex)
                    }
                    vibrator.vibrate(VibrationEffect.createOneShot(10, VibrationEffect.DEFAULT_AMPLITUDE))
                }
                true
            }
            .focusRequester(focusRequester)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        val midX = size.width / 2
                        val isRight = offset.x > midX
                        val direction = if(isRight) 1 else -1

                        if (offset.y < size.height * 0.8f) {
                            if (controlMode == "DECK") {
                                val cmd = if(direction > 0) "NEXT_DECK" else "PREV_DECK"
                                sendBroadcastCommand(context, cmd)
                                playFeedback("DECK", 0)
                            } else {
                                val next = localTargetIndex + direction
                                localTargetIndex = if(next > 8) 0 else if(next < 0) 8 else next
                                
                                val payload = if(localTargetIndex == 8) -1 else localTargetIndex
                                sendBroadcastCommand(context, "SET_TARGET:$payload")
                            }
                            vibrator.vibrate(VibrationEffect.createOneShot(10, VibrationEffect.DEFAULT_AMPLITUDE))
                        }
                    },
                    onLongPress = {
                        controlMode = if(controlMode == "DECK") "TARGET" else "DECK"
                        vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
                        MiniSynth.playTone(1800f, 80)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // --- HEADER ---
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if(controlMode=="DECK") "DECK CONTROL" else "TARGET LINK", color = Color.Gray, fontSize = 8.sp, fontFamily = CyberFont)
                Spacer(modifier = Modifier.width(6.dp))
                Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(if(controlMode=="DECK") primaryColor else Color.DarkGray))
                Spacer(modifier = Modifier.width(3.dp))
                Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(if(controlMode=="TARGET") primaryColor else Color.DarkGray))
            }

            Spacer(modifier = Modifier.height(6.dp))

            // --- MAIN DISPLAY ---
            if (controlMode == "DECK") {
                Text(
                    text = if(isCryo) "SLEEPING" else currentDeck,
                    style = TextStyle(color = primaryColor, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = CyberFont, textAlign = TextAlign.Center),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            } else {
                // TARGET MODE VISUALS
                val isClear = localTargetIndex == 8
                
                // Lookup directly. Since 'targetLabels' is a SnapshotStateMap passed from Main, accessing it here is reactive.
                val rawLabel = targetLabels[localTargetIndex]
                
                // If rawLabel is null, it means no target is set for this index.
                // We show "EMPTY" for the name, and "SLOT X" for the subtext.
                val nameText = if (isClear) "CLEAR" else (rawLabel ?: "EMPTY")
                val subText = if (isClear) "DISENGAGE" else "SLOT ${localTargetIndex + 1}"

                // HERO ELEMENT (Name) - Big Green Text
                Text(
                    text = nameText.uppercase(), 
                    style = TextStyle(
                        color = NeonGreenVal, 
                        fontSize = if(nameText.length > 8) 22.sp else 30.sp, 
                        fontWeight = FontWeight.Black, 
                        fontFamily = CyberFont, 
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                
                // SUBTEXT (Slot Number) - Small Gray Text
                Text(
                    text = subText,
                    color = Color.Gray, 
                    fontSize = 12.sp,
                    fontFamily = CyberFont,
                    fontWeight = FontWeight.Bold
                )

                // ACTIVE INDICATOR (What is currently live in the system)
                if (currentTarget != "NONE" && currentTarget != "-1") {
                    Spacer(modifier = Modifier.height(6.dp))
                     Text(
                        text = "[ ACTIVE: $currentTarget ]",
                        color = Color.DarkGray, 
                        fontSize = 10.sp, 
                        fontFamily = CyberFont
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row {
                Text("<", color = Color.Gray.copy(alpha=0.5f))
                Spacer(modifier = Modifier.width(20.dp))
                Text(">", color = Color.Gray.copy(alpha=0.5f))
            }
        }

        Box(modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp).size(40.dp).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
            Text("✕", color = Color.Gray, fontSize = 14.sp)
        }

        val cryoColor = if(isCryo) NeonBlue else NeonRed.copy(alpha = 0.5f)
        Box(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp).width(100.dp).height(36.dp)
                .clip(CutCornerShape(10.dp)).background(cryoColor.copy(alpha = 0.2f)).border(1.dp, cryoColor, CutCornerShape(10.dp))
                .clickable { 
                    sendBroadcastCommand(context, "CRYO_TOGGLE"); 
                    vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
                    MiniSynth.playTone(150f, 200)
                },
            contentAlignment = Alignment.Center
        ) {
            Text(if(isCryo) "WAKE" else "CRYO", color = if(isCryo) NeonBlue else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = CyberFont)
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(color = primaryColor.copy(alpha = 0.1f + (pulseAlpha * 0.1f)), radius = size.minDimension / 2 - 2.dp.toPx(), style = Stroke(width = 4.dp.toPx()))
        }
    }
}

private fun sendBroadcastCommand(context: Context, command: String) {
    val intent = Intent("com.snakesan.overseer.ACK_CONTROL")
    intent.putExtra("CMD", command)
    intent.setPackage("com.example.besu") 
    context.sendBroadcast(intent)
}
