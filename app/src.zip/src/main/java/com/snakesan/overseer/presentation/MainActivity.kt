package com.snakesan.overseer.presentation

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.ambient.AmbientLifecycleObserver
import androidx.wear.compose.foundation.CurvedLayout
import androidx.wear.compose.foundation.CurvedModifier
import androidx.wear.compose.foundation.padding
import androidx.wear.compose.foundation.curvedRow
import androidx.wear.compose.foundation.curvedColumn
import androidx.wear.compose.material.curvedText
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import com.snakesan.overseer.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.sqrt

// --- CONSTANTS ---
const val ACTION_UPDATE_STATUS = "com.snakesan.overseer.UPDATE_STATUS"
const val ACTION_KILL_SERVICE = "com.snakesan.overseer.KILL_COMMAND"
// NEW: Broadcast for syncing the full list of targets
const val ACTION_SYNC_TARGETS = "com.snakesan.overseer.SYNC_TARGETS"

const val PKG_VITALITY = "com.snakesan.vitalitysys"
const val PKG_ACK = "com.example.besu"
const val PKG_NEON = "com.snakesan.neonflux"

const val PREFS_NAME = "overseer_cache"
const val KEY_DECK_NAME = "cached_deck_name"
const val KEY_DECK_COLOR = "cached_deck_color"
const val KEY_FLUX_MODE = "cached_flux_mode"
const val KEY_HP_LEVEL = "cached_hp_level"
const val KEY_HYD_STATUS = "cached_hyd_status"
const val KEY_MEAL_STATUS = "cached_meal_status"
const val KEY_TARGET_NAME = "cached_target_name"
// NEW: Pref key for the raw target string
const val KEY_TARGET_CACHE = "cached_target_list_raw"

// --- PALETTE ---
val NeonCyanVal = Color(0xFF00F3FF)
val NeonPurple = Color(0xFFD500F9)
val NeonRed = Color(0xFFFF003C)
val NeonGreenVal = Color(0xFF00FF41)
val NeonPink = Color(0xFFFF0055)
val NeonOrange = Color(0xFFFF9100) 
val NeonBlue = Color(0xFF2962FF) 
val NeonDarkVal = Color(0xFF121212)

val CyberFont = FontFamily(Font(R.font.cyberfont))

class MainActivity : ComponentActivity() {

    private val isAmbientState = mutableStateOf(false)
    private val burnInScale = mutableFloatStateOf(1f)

    private var lastInteractionTime = 0L
    private val idleTimeout = 5000L 
    private val frameRateHandler = android.os.Handler(android.os.Looper.getMainLooper())
    
    private val lowPowerRunnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (now - lastInteractionTime >= idleTimeout && !isAmbientState.value) {
                setWindowFrameRate(30f)
            } else {
                frameRateHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(android.R.style.Theme_DeviceDefault)
        startPowerLogging(this, isAmbientState)
        
        bumpActivity()

        val ambientCallback = object : AmbientLifecycleObserver.AmbientLifecycleCallback {
            override fun onEnterAmbient(ambientDetails: AmbientLifecycleObserver.AmbientDetails) {
                isAmbientState.value = true
                burnInScale.floatValue = 1f 
                frameRateHandler.removeCallbacks(lowPowerRunnable)
            }

            override fun onExitAmbient() {
                isAmbientState.value = false
                burnInScale.floatValue = 1f
                bumpActivity()
            }

            override fun onUpdateAmbient() {
                if (isAmbientState.value) {
                    burnInScale.floatValue = (85..100).random() / 100f
                }
            }
        }
        
        val ambientObserver = AmbientLifecycleObserver(this, ambientCallback)
        lifecycle.addObserver(ambientObserver)

        setContent {
            OverseerTheme {
                OverseerUI(
                    isAmbientState = isAmbientState,
                    burnInScale = burnInScale,
                    onInteraction = { bumpActivity() } 
                )
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        frameRateHandler.removeCallbacks(lowPowerRunnable)
    }
    
    private fun bumpActivity() {
        lastInteractionTime = System.currentTimeMillis()
        setWindowFrameRate(0f) 
        frameRateHandler.removeCallbacks(lowPowerRunnable)
        frameRateHandler.postDelayed(lowPowerRunnable, idleTimeout)
    }

    private fun setWindowFrameRate(rate: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val params = window.attributes
                params.preferredRefreshRate = rate
                window.attributes = params
            } catch (e: Exception) { 
                Log.e("OVERSEER", "FPS set failed", e) 
            }
        }
    }
}

@Composable
fun OverseerUI(
    isAmbientState: State<Boolean>, 
    burnInScale: State<Float>,
    onInteraction: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    val isAmbient = isAmbientState.value

    var showAckOverlay by remember { mutableStateOf(false) }
    var emergencyTarget by remember { mutableStateOf<String?>(null) }
    
    var vitalityOffline by remember { mutableStateOf(false) }
    var ackOffline by remember { mutableStateOf(false) }
    var fluxOffline by remember { mutableStateOf(false) }

    val activeTextStyle = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.Normal, color = NeonCyanVal, fontFamily = CyberFont, letterSpacing = (-2).sp)
    val ambientTextStyle = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.Normal, color = Color.White, fontFamily = CyberFont, letterSpacing = (-2).sp, drawStyle = Stroke(width = 2f))

    val infiniteTransition = rememberInfiniteTransition(label = "grid_animations")
    val gridOffsetSlow by if (!isAmbient) infiniteTransition.animateFloat(initialValue = 0f, targetValue = 40f, animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart), label = "s") else remember { mutableFloatStateOf(0f) }
    val gridOffsetFast by if (!isAmbient) infiniteTransition.animateFloat(initialValue = 0f, targetValue = 40f, animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "f") else remember { mutableFloatStateOf(0f) }
    val pulseAlpha by if (!isAmbient) infiniteTransition.animateFloat(initialValue = 1f, targetValue = 0.3f, animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing, delayMillis = 100), RepeatMode.Reverse), label = "p") else remember { mutableFloatStateOf(1f) } 

    var hpLevel by remember { mutableIntStateOf(prefs.getInt(KEY_HP_LEVEL, 100)) }
    var hydStatus by remember { mutableIntStateOf(prefs.getInt(KEY_HYD_STATUS, 1)) }
    var mealStatus by remember { mutableIntStateOf(prefs.getInt(KEY_MEAL_STATUS, 0)) }
    
    var ackDeckName by remember { mutableStateOf(prefs.getString(KEY_DECK_NAME, "ACK") ?: "ACK") }
    var ackColorInt by remember { mutableIntStateOf(prefs.getInt(KEY_DECK_COLOR, NeonCyanVal.toArgb())) }
    
    // Active Target (e.g. "SARAH")
    var ackTargetName by remember { mutableStateOf(prefs.getString(KEY_TARGET_NAME, "NONE") ?: "NONE") }

    // NEW: Full Target Map (Index -> Name)
    val targetMap = remember { mutableStateMapOf<Int, String>() }

    // Initial Load of Targets
    LaunchedEffect(Unit) {
        val raw = prefs.getString(KEY_TARGET_CACHE, "") ?: ""
        parseTargetsToMap(raw, targetMap)
    }
    
    var fluxMode by remember { mutableStateOf(prefs.getString(KEY_FLUX_MODE, "MODE_REACTOR") ?: "MODE_REACTOR") }
    var fluxActive by remember { mutableStateOf(false) }

    var powerUsage by remember { mutableFloatStateOf(0f) }
    var ramUsage by remember { mutableFloatStateOf(0f) }
    var batLevel by remember { mutableFloatStateOf(1f) }
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    
    LaunchedEffect(isAmbient) {
        if (!isAmbient) {
            while(true) {
                currentTime = System.currentTimeMillis()
                withContext(Dispatchers.IO) {
                    ramUsage = getRamUsage(context)
                    batLevel = getBatteryLevel(context)
                    powerUsage = getPowerUsage(context)
                }
                delay(1000L) 
            }
        } else {
            while(true) {
                currentTime = System.currentTimeMillis()
                delay(60000L) 
            }
        }
    }

    DisposableEffect(context, isAmbient) {
        if (isAmbient) {
            onDispose { }
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    intent?.let {
                        val source = it.getStringExtra("source_app") ?: return
                        val editor = prefs.edit()
                        when(source) {
                            "VITALITY" -> { 
                                vitalityOffline = false
                                hpLevel = it.getIntExtra("hp", 100)
                                hydStatus = it.getIntExtra("hyd_status", 1)
                                mealStatus = it.getIntExtra("meal_status", 0)
                                editor.putInt(KEY_HP_LEVEL, hpLevel).putInt(KEY_HYD_STATUS, hydStatus).putInt(KEY_MEAL_STATUS, mealStatus).apply() 
                            }
                            "ACK" -> { 
                                ackOffline = false
                                ackDeckName = it.getStringExtra("active_deck")?:"ACK"
                                ackColorInt = it.getIntExtra("deck_color", NeonCyanVal.toArgb())
                                
                                // Capture active target
                                ackTargetName = it.getStringExtra("active_target") ?: "NONE"
                                
                                editor.putString(KEY_DECK_NAME, ackDeckName)
                                      .putInt(KEY_DECK_COLOR, ackColorInt)
                                      .putString(KEY_TARGET_NAME, ackTargetName)
                                      .apply() 
                            }
                            "ACK_SENSOR" -> { 
                                ackOffline = false
                                val s = it.getStringExtra("sensor_state")?:"IDLE"
                                ackColorInt = when(s) {
                                    "ARMED" -> Color.Red.toArgb()
                                    "LOCKED" -> Color.Green.toArgb()
                                    "CRYO" -> NeonBlue.toArgb()
                                    else -> prefs.getInt(KEY_DECK_COLOR, NeonCyanVal.toArgb())
                                }
                                ackDeckName = when {
                                    s == "CRYO" -> "SLEEP"
                                    s != "IDLE" -> (it.getStringExtra("sensor_pose")?:"NONE").takeIf{p->p!="NONE"}?:s
                                    else -> prefs.getString(KEY_DECK_NAME, "ACK")?:"ACK"
                                }
                                // Also update target display from sensor
                                ackTargetName = it.getStringExtra("active_target") ?: ackTargetName
                            }
                            // NEW: Handle Target List Sync
                            "ACK_LIST_SYNC" -> {
                                val rawList = it.getStringExtra("raw_targets") ?: ""
                                editor.putString(KEY_TARGET_CACHE, rawList).apply()
                                parseTargetsToMap(rawList, targetMap)
                            }
                            "FLUX" -> { fluxOffline = false; fluxMode = it.getStringExtra("flux_mode")?:"MODE_REACTOR"; fluxActive = it.getBooleanExtra("is_active", false); editor.putString(KEY_FLUX_MODE, fluxMode).apply() }
                        }
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(ACTION_UPDATE_STATUS)
                addAction(ACTION_SYNC_TARGETS) // Add new action
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Context.RECEIVER_EXPORTED else 0
            context.registerReceiver(receiver, filter, flags)
            onDispose { context.unregisterReceiver(receiver) }
        }
    }

    val rawHpColor = when { hpLevel > 75 -> NeonGreenVal; hpLevel > 50 -> NeonOrange; else -> NeonRed }
    val currentHpColor = if (isAmbient) { if (vitalityOffline) Color.Transparent else Color.Gray } else { if (vitalityOffline) Color.DarkGray else (if (hpLevel <= 50) rawHpColor.copy(alpha = pulseAlpha) else rawHpColor) }
    val currentAckColor = if (isAmbient) { if (ackOffline) Color.Transparent else Color.Gray } else { if (ackOffline) Color.DarkGray else Color(ackColorInt) }
    val activeFluxColor = when(fluxMode) { "MODE_REACTOR" -> NeonCyanVal; "MODE_REACTOR_AUDIO" -> NeonPurple; "MODE_CLINICAL" -> NeonRed; else -> NeonPink }
    val currentFluxColor = if (isAmbient) { if (fluxOffline) Color.Transparent else Color.Gray } else { if (fluxOffline) Color.DarkGray else (if (fluxActive) activeFluxColor else NeonPink) }
    
    val calendar = Calendar.getInstance().apply { timeInMillis = currentTime }
    val is24 = DateFormat.is24HourFormat(context)
    val displayHour = if (!is24 && calendar.get(Calendar.HOUR)==0) 12 else if(is24) calendar.get(Calendar.HOUR_OF_DAY) else calendar.get(Calendar.HOUR)
    val timeString = String.format(Locale.US, "%02d:%02d", displayHour, calendar.get(Calendar.MINUTE))
    val secString = String.format(Locale.US, "%02d", calendar.get(Calendar.SECOND))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .scale(if (isAmbient) burnInScale.value else 1f)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { tapOffset -> 
                        if (isAmbient) return@detectTapGestures
                        onInteraction()
                        
                        val cx = size.width/2; val cy = size.height/2
                        val dist = sqrt(Math.pow((tapOffset.x-cx).toDouble(), 2.0) + Math.pow((tapOffset.y-cy).toDouble(), 2.0))
                        if (dist > (size.width/2)*0.25f) {
                            var ang = Math.toDegrees(atan2(tapOffset.y-cy, tapOffset.x-cx).toDouble()) + 90
                            if (ang < 0) ang += 360
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            when { 
                                ang <= 120 -> launchApp(context, PKG_VITALITY)
                                ang <= 240 -> showAckOverlay = true
                                else -> launchApp(context, PKG_NEON) 
                            }
                        }
                    },
                    onLongPress = { tapOffset ->
                        if (isAmbient) return@detectTapGestures
                        onInteraction()
                        
                        val cx = size.width/2; val cy = size.height/2
                        val dist = sqrt(Math.pow((tapOffset.x-cx).toDouble(), 2.0) + Math.pow((tapOffset.y-cy).toDouble(), 2.0))
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (dist <= (size.width/2)*0.25f) emergencyTarget = "ALL"
                        else {
                            var ang = Math.toDegrees(atan2(tapOffset.y-cy, tapOffset.x-cx).toDouble()) + 90
                            if (ang < 0) ang += 360
                            when { ang <= 120 -> emergencyTarget = PKG_VITALITY; ang <= 240 -> emergencyTarget = PKG_ACK; else -> emergencyTarget = PKG_NEON }
                        }
                    }
                )
            }
    ) {
        // ... (Canvas drawing logic) ...
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            if (!isAmbient) {
                drawCircle(color = NeonDarkVal) 
                val g = 40f
                for (i in -1..12) { val p = (i*g)+gridOffsetSlow; val x=i*g; drawLine(Color.DarkGray.copy(0.25f), Offset(x,0f), Offset(x,h), 1f); drawLine(Color.DarkGray.copy(0.25f), Offset(0f,p), Offset(w,p), 1f) }
                for (i in -2..12) { val m = (i*g)+gridOffsetFast; drawLine(NeonCyanVal.copy(0.2f), Offset(m,0f), Offset(m,h), 1f); drawLine(NeonCyanVal.copy(0.2f), Offset(0f,m), Offset(w,m), 1f) }
            } else { drawCircle(color = Color.Black) }
            
            val sw = if(isAmbient) 4f else 18f
            if(!isAmbient) drawArc(NeonGreenVal.copy(0.15f), -87f, 114f, false, style=Stroke(sw, cap=StrokeCap.Butt))
            drawArc(currentHpColor, -87f, (114f*(hpLevel/100f)).coerceIn(0f,114f), false, style=Stroke(sw, cap=StrokeCap.Butt))
            drawArc(currentAckColor, 33f, 114f, false, style=Stroke(sw, cap=StrokeCap.Butt))
            drawArc(currentFluxColor, 153f, 114f, false, style=Stroke(sw, cap=StrokeCap.Butt))
            
            if (!isAmbient) {
                val ir = (size.minDimension/2)*0.55f; val ms=80f; val tl=Offset(w/2-ir, h/2-ir); val sz=Size(ir*2,ir*2)
                drawArc(Color.Gray.copy(0.3f), 230f, ms, false, topLeft=tl, size=sz, style=Stroke(6f))
                drawArc(lerpColor(NeonGreenVal, NeonRed, ramUsage), 230f, ms*ramUsage, false, topLeft=tl, size=sz, style=Stroke(6f))
                drawArc(Color.Gray.copy(0.3f), 350f, ms, false, topLeft=tl, size=sz, style=Stroke(6f))
                drawArc(lerpColor(NeonRed, NeonGreenVal, batLevel), 350f, ms*batLevel, false, topLeft=tl, size=sz, style=Stroke(6f))
                drawArc(Color.Gray.copy(0.3f), 110f, ms, false, topLeft=tl, size=sz, style=Stroke(6f))
                drawArc(lerpColor(NeonGreenVal, NeonRed, powerUsage), 110f, ms*powerUsage, false, topLeft=tl, size=sz, style=Stroke(6f))
                val r=20f; drawLine(NeonCyanVal.copy(0.5f), Offset(w/2-r,h/2), Offset(w/2+r,h/2), 2f); drawLine(NeonCyanVal.copy(0.5f), Offset(w/2,h/2-r), Offset(w/2,h/2+r), 2f)
            } else { drawCircle(Color.Gray, radius=(size.minDimension/2)*0.55f, style=Stroke(2f)) }
        }

        CurvedLayout(anchor = 330f) {
            curvedRow(modifier = CurvedModifier.padding(radial = 5.dp)) {
                if (!vitalityOffline) {
                    val hydText = when(hydStatus) { 0 -> "LOW"; 2 -> "HI"; else -> "NOM" }
                    val unifiedHydColor = when(hydStatus) { 0 -> NeonRed; 2 -> NeonOrange; else -> NeonCyanVal }
                    curvedText(text = "H2O ", fontSize = 8.sp, color = if(isAmbient) Color.Gray else unifiedHydColor, fontWeight = FontWeight.Bold)
                    curvedText(text = hydText, color = if(isAmbient) Color.Gray else unifiedHydColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                curvedColumn(modifier = CurvedModifier.padding(angular = 12.dp)) {
                    curvedText(text = "HP $hpLevel", color = currentHpColor.let { if (it == Color.Transparent) Color.Gray else it }, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    if (vitalityOffline) curvedText(text = "OFFLINE", color = if (isAmbient) Color.White else NeonRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                if (!vitalityOffline && mealStatus != 0) {
                    val mealText = if (mealStatus == 1) "PREP" else "REQ"
                    val mealColor = if (mealStatus == 1) NeonCyanVal else NeonOrange
                    curvedText(text = mealText, color = if(isAmbient) Color.Gray else mealColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    curvedText(text = " MEAL", fontSize = 12.sp, color = if(isAmbient) Color.Gray else mealColor, fontWeight = FontWeight.Bold)
                }
            }
        }

        // --- ACK WEDGE ---
        CurvedLayout(anchor=90f){
            curvedColumn(modifier=CurvedModifier.padding(radial=5.dp)){
                curvedText(ackDeckName, color=currentAckColor.let{if(it==Color.Transparent)Color.Gray else it}, fontSize=14.sp, fontWeight=FontWeight.Bold)

                // --- UPDATED TARGET INDICATOR ---
                if (ackTargetName != "NONE" && ackTargetName != "-1") {
                    // AoD LOGIC: If Ambient, use Gray. If Active, use Green.
                    val wedgeColor = if (isAmbient) Color.Gray else NeonGreenVal

                    curvedText(
                        text = ">> $ackTargetName",
                        color = wedgeColor, // <--- CHANGED HERE
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Normal
                    )
                }

                if(ackOffline) curvedText("OFFLINE", color=if(isAmbient)Color.White else NeonRed, fontSize=10.sp, fontWeight=FontWeight.Bold)
            }
        }
        
        CurvedLayout(anchor=210f){ curvedColumn(modifier=CurvedModifier.padding(radial=5.dp)){ curvedText(if(fluxActive) fluxMode.removePrefix("MODE_") else "STBY", color=currentFluxColor.let{if(it==Color.Transparent)Color.Gray else it}, fontSize=14.sp, fontWeight=FontWeight.Bold); if(fluxOffline) curvedText("OFFLINE", color=if(isAmbient)Color.White else NeonRed, fontSize=10.sp, fontWeight=FontWeight.Bold) } }

        Box(modifier = Modifier.align(Alignment.Center)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = timeString, style = if (isAmbient) ambientTextStyle else activeTextStyle)
                if (!isAmbient) Text(text = secString, style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Normal, color = NeonCyanVal.copy(alpha = 0.5f), fontFamily = CyberFont, letterSpacing = 2.sp))
            }
        }
        
        if (emergencyTarget != null) {
            EmergencyOverlay(target = emergencyTarget!!, onDismiss = { emergencyTarget = null }, onConfirm = { performKill(context, emergencyTarget!!); when(emergencyTarget){PKG_VITALITY->vitalityOffline=true; PKG_ACK->ackOffline=true; PKG_NEON->fluxOffline=true; "ALL"->{vitalityOffline=true;ackOffline=true;fluxOffline=true}}; emergencyTarget=null })
        }

        // --- ACK OVERLAY POPUP ---
        if (showAckOverlay) {
            val isCryo = ackDeckName == "SLEEP" || ackDeckName == "CRYO"
            AckControlOverlay(
                currentDeck = ackDeckName,
                currentTarget = ackTargetName,
                targetLabels = targetMap, // PASS THE MAP
                currentColor = ackColorInt,
                isCryo = isCryo,
                onDismiss = { showAckOverlay = false }
            )
        }
    }
}

// --- HELPER FUNCTION FOR PARSING TARGETS ---
fun parseTargetsToMap(raw: String, map: MutableMap<Int, String>) {
    map.clear()
    if (raw.isEmpty()) return
    // Format expected: "0:SARAH|1:WORK|2:BOSS"
    try {
        raw.split("|").forEach { entry ->
            val parts = entry.split(":")
            if (parts.size == 2) {
                val idx = parts[0].toIntOrNull()
                if (idx != null) map[idx] = parts[1]
            }
        }
    } catch (e: Exception) { Log.e("OVERSEER", "Target Parse Error", e) }
}

@Composable
fun EmergencyOverlay(target: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val targetName = if (target == "ALL") "SYSTEM" else target.substringAfterLast('.')

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.9f))
            .clickable(enabled=false){} // Block touches
            .border(2.dp, NeonRed, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
            Text("EMERGENCY STOP", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = CyberFont)
            Spacer(modifier = Modifier.height(8.dp))
            Text("TERMINATE $targetName?", color = Color.White, textAlign = TextAlign.Center, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(
                    onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onDismiss() },
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.DarkGray)
                ) { Text("CNCL", fontSize = 12.sp) }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onConfirm() },
                    colors = ButtonDefaults.buttonColors(backgroundColor = NeonRed)
                ) { Text("KILL", fontSize = 12.sp) }
            }
        }
    }
}

fun performKill(context: Context, target: String) {
    val intent = Intent(ACTION_KILL_SERVICE).apply {
        putExtra("target_package", target)
        // If ALL, we broadcast generally. If specific, we target that package.
        setPackage(if (target == "ALL") null else target)
    }
    context.sendBroadcast(intent)
}

fun startPowerLogging(context: Context, isAmbientState: State<Boolean>) {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val file = File(context.cacheDir, "power_log_${System.currentTimeMillis()}.csv")
    val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.IO)

    scope.launch(Dispatchers.IO) {
        try {
            FileOutputStream(file).use { fos ->
                fos.write("TIMESTAMP,CURRENT_UA,CAPACITY_PCT\n".toByteArray())
                while(true) {
                    // Don't log in ambient mode to save power
                    if (isAmbientState.value) {
                        delay(10000L)
                        continue
                    }

                    val ua = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                    val cap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())

                    fos.write("$ts,$ua,$cap\n".toByteArray())
                    delay(250)
                }
            }
        } catch (e: Exception) {
            Log.e("OVERSEER_LOG", "Logging failed", e)
        }
    }
}

fun getBatteryLevel(context: Context): Float {
    val s = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { context.registerReceiver(null, it) }
    val l = s?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val sc = s?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    return if (l != -1 && sc != -1) l / sc.toFloat() else 0.5f
}

fun getRamUsage(context: Context): Float {
    val a = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val m = ActivityManager.MemoryInfo()
    a.getMemoryInfo(m)
    return if (m.totalMem == 0L) 0f else (m.totalMem - m.availMem).toFloat() / m.totalMem.toFloat()
}

fun getPowerUsage(context: Context): Float {
    val b = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    // Normalize based on arbitrary max current (600mA) for visualization
    return (abs(b.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)) / 1000f / 600f).coerceIn(0f, 1f)
}

fun lerpColor(start: Color, end: Color, fraction: Float): Color {
    val f = fraction.coerceIn(0f, 1f)
    return Color(
        start.red + (end.red - start.red) * f,
        start.green + (end.green - start.green) * f,
        start.blue + (end.blue - start.blue) * f
    )
}

fun launchApp(context: Context, packageName: String) {
    try {
        val i = context.packageManager.getLaunchIntentForPackage(packageName)
        if (i != null) context.startActivity(i)
        else Log.e("OVERSEER", "App not found: $packageName")
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
